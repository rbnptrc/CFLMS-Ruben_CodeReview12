<?php get_header(); ?>


<!-- All dynamic content will come in here -->

<main>

    <div class="container-fluid m-2">
    <div class="row row-cols-md-2 row-cols-lg-4 justify-content-center">

            <?php if (have_posts()) : ?>

                <?php while (have_posts()) : the_post(); ?>

                    <div class="card-deck">

                        <div class="card mb-5">

                            <div class="card-body">
                            <div class="image-box">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php echo the_post_thumbnail('medium'); ?>
                                <?php endif; ?>
                            </div>


                                <p class="get-cat"><?php the_category(); ?></p>

                                <h5 class="card-title"><a href="<?php the_permalink(); ?>">
                                        <?php the_title(); ?></h5></a>
                                <hr class="short-line">
                                <p> <?php the_excerpt(); ?></p>

                            </div>
                            <div class="card-footer text-left mt-2 small">Author: <?php the_author(); ?> on <?php the_time('Y'); ?>
                            </div>
                        </div>
                    </div>

                <?php endwhile; ?>
                <!--end the while loop-->

            <?php else : ?>
                <!-- if no posts are found then: -->

                <p>No posts found</p> <!-- no posts found displayed -->
            <?php endif; ?>
            <!-- end if -->

        </div>
    </div>
    </div>
</main>
<?php get_footer(); ?>