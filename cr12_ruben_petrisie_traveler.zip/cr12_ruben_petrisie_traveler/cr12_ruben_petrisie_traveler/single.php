<?php get_header(); ?>

<div class="container text-center">
    <div class="blog-title">
        <h3>BLOG STORIES</h3>
    </div>
<hr class="title-line">
<br>


    <?php if (have_posts()) : ?>
        <!--  If there are posts available  -->

          <h4><?php the_title(); ?></h4>  
<div class="thumb">

            <!--retrieves blog title-->
    <?php if (has_post_thumbnail()) : ?>
        <?php the_post_thumbnail('medium_large'); ?>
        <?php endif; ?>
</div>
        
        <?php while (have_posts()) : the_post(); ?>
            <!-- if there are posts, iterate the posts in the loop--->
           <p><?php the_category(); ?></p> 
             <?php the_content(); ?>
            <!--retrieves content-->

            <p><?php previous_post_link(); ?>Previous</p> | <p><?php next_post_link(); ?>Next</p>


<br>


<?php endwhile; ?>
<!--end the while loop-->


<br>


<?php else : ?>
    <!-- if no posts are found then: -->
   
    <p>No posts found</p>
    <?php endif; ?>
   <!-- end if -->

   <!---activate comments--->
    <hr>    
    <?php
    comments_template( '', true );
    ?>
 

    </div>
               
</div>

<?php get_footer(); ?>