
   
<?php get_header(); ?>

<?php
        while ( have_posts() ) : the_post();
            the_content();
        endwhile; // End of the loop.
        ?>

        
<?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
?>

<?php get_footer(); ?>

