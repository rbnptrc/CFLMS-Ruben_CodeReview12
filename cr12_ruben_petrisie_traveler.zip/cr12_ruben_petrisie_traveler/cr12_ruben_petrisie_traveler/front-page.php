<?php

/**
* Template Name: front-Page
 **/
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="description" content="<?php bloginfo('description'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php bloginfo('Page CF'); ?>
        <?php is_front_page() ? bloginfo('description') : wp_title(); ?>
    </title>
    <!---<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
    <link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/bootstrap.css">--->
    <?php wp_head(); ?>

</head>

<body <?php body_class(); ?> style="background: #6FBB72 url(<?php echo $src = the_post_thumbnail_url('wp-content/uploads/2020/07/screenshot-1024x683.jpg'); ?> ) repeat 50% 0 fixed !important;">

    <div class="content">

        <h2 class="landing-t">MOUNT EVEREST TRAVEL AGENCY</h2>

        <div class="landing-btn">
            <a href="http://localhost/codefactory2/home/" class="btn btn-light">DISCOVER US</a>

        </div>
    </div>

</body>

</html>